package ai_Chef;

public class InputValidator {
    public static boolean isValidQuery(String query) {
        return query != null && !query.trim().isEmpty();
    }
}
