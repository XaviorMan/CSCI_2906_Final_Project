package ai_Chef;
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class NavigationPanel extends JPanel {
    private static final long serialVersionUID = 1L;
    private JPanel mainPanel;
    private CardLayout cardLayout;
    private ClockAndTimer clockAndTimer;

    public NavigationPanel(ClockAndTimer clockAndTimer) {
        this.clockAndTimer = clockAndTimer;
        setLayout(new FlowLayout(FlowLayout.LEFT));

        JButton homeButton = new JButton("Home");
        JButton fridgeButton = new JButton("Fridge");
        JButton recipesButton = new JButton("Recipes");
        JButton settingsButton = new JButton(new ImageIcon("settings_icon.png")); // Placeholder for settings icon

        add(homeButton);
        add(fridgeButton);
        add(recipesButton);
        add(settingsButton);

        // Add digital clock and timer
        clockAndTimer.setPreferredSize(new Dimension(100, 30));
        add(clockAndTimer);

        homeButton.addActionListener(new SwitchPanelAction("Home"));
        fridgeButton.addActionListener(new SwitchPanelAction("Fridge"));
        recipesButton.addActionListener(new SwitchPanelAction("Recipes"));
        settingsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openSettingsDialog();
            }
        });
    }

    public void setMainPanel(JPanel mainPanel) {
        this.mainPanel = mainPanel;
        this.cardLayout = (CardLayout) mainPanel.getLayout();
    }

    private class SwitchPanelAction implements ActionListener {
        private String panelName;

        public SwitchPanelAction(String panelName) {
            this.panelName = panelName;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            cardLayout.show(mainPanel, panelName);
        }
    }

    private void openSettingsDialog() {
        JDialog settingsDialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Settings", true);
        settingsDialog.setSize(300, 200);
        settingsDialog.setLayout(new BorderLayout());

        // Add SettingsPanel to the dialog
        SettingsPanel settingsPanel = new SettingsPanel(clockAndTimer);
        settingsDialog.add(settingsPanel, BorderLayout.CENTER);

        settingsDialog.setVisible(true);
    }
}
