import java.util.List;

public class RecipeService {
    private RecipeSearch recipeSearch;

    public RecipeService(RecipeSearch recipeSearch) {
        this.recipeSearch = recipeSearch;
    }

    public List<String> findRecipes(String query) {
        return recipeSearch.searchRecipesByIngredient(query);
    }
}
