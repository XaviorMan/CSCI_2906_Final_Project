import javax.swing.*;
import java.awt.*;

public class AIChefApp {

    // Define JLabels that will be updated with dynamic content
    private static JLabel breakfastLabel = new JLabel(" ");
    private static JLabel lunchLabel = new JLabel(" ");
    private static JLabel dinnerLabel = new JLabel(" ");
    private static JLabel[] weekDayLabels = new JLabel[7];
    private static JLabel[][] weekMealLabels = new JLabel[7][3];
    private static JLabel[][] calendarLabels = new JLabel[6][7]; // Standard 6 rows for calendar view

    // CardLayout and main panel for switching between pages
    private static CardLayout cardLayout = new CardLayout();
    private static JPanel mainPanel = new JPanel(cardLayout);

    public static void main(String[] args) {
        // Create the frame
        JFrame frame = new JFrame("AI Chef");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 1000); // Increased the size to accommodate larger panels

        // Create the Home panel
        JPanel homePanel = createHomePanel();

        // Create the Fridge panel
        JPanel fridgePanel = createFridgePanel();

        // Create the Recipes panel
        JPanel recipesPanel = createRecipesPanel();

        // Create the Settings panel
        JPanel settingsPanel = createSettingsPanel();

        // Add the panels to the CardLayout
        mainPanel.add(homePanel, "Home");
        mainPanel.add(fridgePanel, "Fridge");
        mainPanel.add(recipesPanel, "Recipes");
        mainPanel.add(settingsPanel, "Settings");

        // Add the main panel to the frame
        frame.add(mainPanel);
        frame.setVisible(true);
    }

    private static JPanel createNavPanel() {
        // Create the top navigation panel
        JPanel navPanel = new JPanel(new GridLayout(1, 4));
        JButton homeButton = new JButton("Home");
        JButton fridgeButton = new JButton("Fridge");
        JButton recipesButton = new JButton("Recipes");
        JButton settingsButton = new JButton("⚙");

        // Add action listeners to the buttons
        homeButton.addActionListener(e -> cardLayout.show(mainPanel, "Home"));
        fridgeButton.addActionListener(e -> cardLayout.show(mainPanel, "Fridge"));
        recipesButton.addActionListener(e -> cardLayout.show(mainPanel, "Recipes"));
        settingsButton.addActionListener(e -> cardLayout.show(mainPanel, "Settings"));

        navPanel.add(homeButton);
        navPanel.add(fridgeButton);
        navPanel.add(recipesButton);
        navPanel.add(settingsButton);

        return navPanel;
    }

    private static JPanel createHomePanel() {
        // Create the home panel with BorderLayout
        JPanel homePanel = new JPanel(new BorderLayout());

        // Add navigation panel
        JPanel navPanel = createNavPanel();
        homePanel.add(navPanel, BorderLayout.NORTH);

        // Create the day panel
        JPanel dayPanel = new JPanel(new GridLayout(2, 3));
        dayPanel.setBorder(BorderFactory.createTitledBorder("Day"));
        dayPanel.add(new JLabel("Breakfast:", SwingConstants.CENTER));
        dayPanel.add(new JLabel("Lunch:", SwingConstants.CENTER));
        dayPanel.add(new JLabel("Dinner:", SwingConstants.CENTER));
        dayPanel.add(breakfastLabel);
        dayPanel.add(lunchLabel);
        dayPanel.add(dinnerLabel);

        // Create the week panel
        JPanel weekPanel = new JPanel(new GridLayout(2, 7));
        weekPanel.setBorder(BorderFactory.createTitledBorder("Week"));
        String[] daysOfWeek = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
        for (int i = 0; i < 7; i++) {
            weekDayLabels[i] = new JLabel(daysOfWeek[i], SwingConstants.CENTER);
            weekPanel.add(weekDayLabels[i]);
        }
        for (int i = 0; i < 7; i++) {
            JPanel mealColumn = new JPanel(new GridLayout(3, 1));
            mealColumn.add(new JLabel("B:", SwingConstants.LEFT));
            weekMealLabels[i][0] = new JLabel(" ");
            mealColumn.add(weekMealLabels[i][0]);
            mealColumn.add(new JLabel("L:", SwingConstants.LEFT));
            weekMealLabels[i][1] = new JLabel(" ");
            mealColumn.add(weekMealLabels[i][1]);
            mealColumn.add(new JLabel("D:", SwingConstants.LEFT));
            weekMealLabels[i][2] = new JLabel(" ");
            mealColumn.add(weekMealLabels[i][2]);
            weekPanel.add(mealColumn);
        }

        // Create the calendar panel
        JPanel calendarPanel = new JPanel(new GridLayout(6, 7)); // Standard 6 rows for calendar view
        calendarPanel.setBorder(BorderFactory.createTitledBorder("Calendar"));
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                calendarLabels[i][j] = new JLabel(" ", SwingConstants.CENTER);
                calendarLabels[i][j].setBorder(BorderFactory.createLineBorder(Color.BLACK));
                calendarPanel.add(calendarLabels[i][j]);
            }
        }

        // Create the FunTabBox with three tabs
        JTabbedPane funTabBox = new JTabbedPane();
        JPanel randomizerPanel = new JPanel();
        JPanel snackOfTheDayPanel = new JPanel();
        JPanel funFoodFactsPanel = new JPanel();
        funTabBox.addTab("Randomizer", randomizerPanel);
        funTabBox.addTab("Snack of the Day", snackOfTheDayPanel);
        funTabBox.addTab("Fun Food Facts", funFoodFactsPanel);
        funTabBox.setBorder(BorderFactory.createTitledBorder("FunTabBox"));

        // Create the right tabbed pane
        JTabbedPane tabbedPane = new JTabbedPane();
        JPanel ingredientsPanel = new JPanel();
        JPanel shoppingPanel = new JPanel();
        tabbedPane.addTab("Ingredients", ingredientsPanel);
        tabbedPane.addTab("Shopping", shoppingPanel);

        // Add components to the home panel
        JPanel topCenterPanel = new JPanel(new GridLayout(2, 1)); // To stack day and week panels
        topCenterPanel.add(dayPanel);
        topCenterPanel.add(weekPanel);

        JPanel upperPanel = new JPanel(new BorderLayout());
        upperPanel.add(topCenterPanel, BorderLayout.NORTH);
        upperPanel.add(Box.createVerticalStrut(20), BorderLayout.SOUTH); // Empty space for visual separation

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(upperPanel, BorderLayout.NORTH);
        centerPanel.add(calendarPanel, BorderLayout.CENTER);
        centerPanel.add(funTabBox, BorderLayout.SOUTH);

        homePanel.add(navPanel, BorderLayout.NORTH);
        homePanel.add(centerPanel, BorderLayout.CENTER);
        homePanel.add(tabbedPane, BorderLayout.EAST);

        return homePanel;
    }

    private static JPanel createFridgePanel() {
        // Create the fridge panel
        JPanel fridgePanel = new JPanel(new BorderLayout());

        // Add navigation panel
        JPanel navPanel = createNavPanel();
        fridgePanel.add(navPanel, BorderLayout.NORTH);

        // Main sections
        JPanel mainSection = new JPanel(new GridLayout(2, 2, 10, 10)); // 2x2 grid layout with some space between sections

        // Fridge
        JPanel fridgeSection = new JPanel(new BorderLayout());
        fridgeSection.setBorder(BorderFactory.createTitledBorder("Fridge"));
        JList<String> fridgeList = new JList<>(new DefaultListModel<>());
        JScrollPane fridgeScrollPane = new JScrollPane(fridgeList);
        fridgeSection.add(fridgeScrollPane, BorderLayout.CENTER);
        mainSection.add(fridgeSection);

        // Freezer
        JPanel freezerSection = new JPanel(new BorderLayout());
        freezerSection.setBorder(BorderFactory.createTitledBorder("Freezer"));
        JList<String> freezerList = new JList<>(new DefaultListModel<>());
        JScrollPane freezerScrollPane = new JScrollPane(freezerList);
        freezerSection.add(freezerScrollPane, BorderLayout.CENTER);
        mainSection.add(freezerSection);

        // Pantry
        JPanel pantrySection = new JPanel(new BorderLayout());
        pantrySection.setBorder(BorderFactory.createTitledBorder("Pantry"));
        JList<String> pantryList = new JList<>(new DefaultListModel<>());
        JScrollPane pantryScrollPane = new JScrollPane(pantryList);
        pantrySection.add(pantryScrollPane, BorderLayout.CENTER);
        mainSection.add(pantrySection);

        // Spice Cabinet
        JPanel spiceCabinetSection = new JPanel(new BorderLayout());
        spiceCabinetSection.setBorder(BorderFactory.createTitledBorder("Spice Cabinet"));
        JList<String> spiceCabinetList = new JList<>(new DefaultListModel<>());
        JScrollPane spiceCabinetScrollPane = new JScrollPane(spiceCabinetList);
        spiceCabinetSection.add(spiceCabinetScrollPane, BorderLayout.CENTER);
        mainSection.add(spiceCabinetSection);

        // Add the main sections to the fridge panel
        fridgePanel.add(mainSection, BorderLayout.CENTER);

        // Deep Freezer
        JPanel deepFreezerSection = new JPanel(new BorderLayout());
        deepFreezerSection.setBorder(BorderFactory.createTitledBorder("Deep Freezer"));
        JList<String> deepFreezerList = new JList<>(new DefaultListModel<>());
        JScrollPane deepFreezerScrollPane = new JScrollPane(deepFreezerList);
        deepFreezerSection.add(deepFreezerScrollPane, BorderLayout.CENTER);

    }
}

       
