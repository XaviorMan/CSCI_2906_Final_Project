import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class AIChefGUI extends JFrame {
    private JTextField searchField;
    private JButton searchButton;
    private JTextArea resultArea;
    private RecipeService recipeService;

    public AIChefGUI(DatabaseManager dbManager) {
        // Set up the frame
        setTitle("AI Chef");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Initialize RecipeService
        RecipeSearch recipeSearch = new RecipeSearch(dbManager);
        recipeService = new RecipeService(recipeSearch);

        // Create GUI components
        searchField = new JTextField();
        searchButton = new JButton("Search Recipes");
        resultArea = new JTextArea();
        
        // Add components to the frame
        add(searchField, BorderLayout.NORTH);
        add(searchButton, BorderLayout.CENTER);
        add(new JScrollPane(resultArea), BorderLayout.SOUTH);

        // Add action listener to the button
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                searchRecipes();
            }
        });
    }

    private void searchRecipes() {
        String query = searchField.getText();
        if (InputValidator.isValidQuery(query)) {
            List<String> recipes = recipeService.findRecipes(query);
            resultArea.setText(ResponseFormatter.formatRecipes(recipes));
        } else {
            resultArea.setText("Invalid query. Please enter a valid search term.");
        }
    }

    public static void main(String[] args) {
        DatabaseManager dbManager = new DatabaseManager();
        dbManager.connect();
        
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new AIChefGUI(dbManager).setVisible(true);
            }
        });

        // Close the database connection on exit
        Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                dbManager.disconnect();
            }
        });
    }
}
