package ai_Chef;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.List;

public class RecipeSearch {
    private static final Logger logger = LogManager.getLogger(RecipeSearch.class);
    private RecipeService recipeService;

    public RecipeSearch() {
        this.recipeService = new RecipeService();
    }

    public void performSearch(String query) {
        List<Recipe> results = recipeService.searchRecipe(query);
        if (results.isEmpty()) {
            logger.info("No recipes found for query: " + query);
        } else {
            logger.info("Found " + results.size() + " recipes for query: " + query);
            for (Recipe recipe : results) {
                logger.info(recipe.toString());
            }
        }
    }
}
