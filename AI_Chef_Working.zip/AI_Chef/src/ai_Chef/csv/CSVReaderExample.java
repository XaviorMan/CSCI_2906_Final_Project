package ai_Chef.csv;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.io.IOException;
import java.util.List;
import java.util.Arrays;

public class CSVReaderExample {
    public void readCSV() {
        try (InputStream is = getClass().getResourceAsStream("/datasets/data.csv");
             InputStreamReader isr = new InputStreamReader(is);
             CSVReader reader = new CSVReader(isr)) {
            
            List<String[]> lines = reader.readAll();
            for (String[] line : lines) {
                System.out.println(Arrays.toString(line));
            }
        } catch (IOException | CsvException e) {
            e.printStackTrace();
        }
    }
}
