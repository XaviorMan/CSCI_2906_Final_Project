package ai_Chef;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class RecipePanel extends JPanel {
    private JList<String> recipeList;
    private DefaultListModel<String> listModel;
    private JTextArea recipeDetails;
    private JTextField searchField;
    private JButton searchButton;

    public RecipePanel() {
        setLayout(new BorderLayout());

        // Recipe List
        listModel = new DefaultListModel<>();
        recipeList = new JList<>(listModel);
        recipeList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane listScrollPane = new JScrollPane(recipeList);

        // Recipe Details
        recipeDetails = new JTextArea();
        recipeDetails.setEditable(false);
        JScrollPane detailsScrollPane = new JScrollPane(recipeDetails);

        // Search Bar
        JPanel searchPanel = new JPanel();
        searchField = new JTextField(20);
        searchButton = new JButton("Search");
        searchPanel.add(searchField);
        searchPanel.add(searchButton);

        // Add Components
        add(searchPanel, BorderLayout.NORTH);
        add(listScrollPane, BorderLayout.WEST);
        add(detailsScrollPane, BorderLayout.CENTER);

        // Event Listeners
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String query = searchField.getText();
                searchRecipes(query);
            }
        });

        recipeList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                String selectedRecipe = recipeList.getSelectedValue();
                displayRecipeDetails(selectedRecipe);
            }
        });
    }

    private void searchRecipes(String query) {
        // Call backend service to get search results
        List<String> results = RecipeService.searchRecipes(query);
        listModel.clear();
        for (String recipe : results) {
            listModel.addElement(recipe);
        }
    }

    private void displayRecipeDetails(String recipeName) {
        // Call backend service to get recipe details
        String details = RecipeService.getRecipeDetails(recipeName);
        recipeDetails.setText(details);
    }
}
