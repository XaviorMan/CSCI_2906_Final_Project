package ai_Chef;

import javax.swing.JLabel;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Timer;
import java.util.TimerTask;

public class ClockAndTimer extends JLabel {
    private static final long serialVersionUID = 1L;
    private boolean isMilitaryTime;
    private Timer timer;
    private LocalTime timerTime;
    private boolean isTimerRunning;

    public ClockAndTimer() {
        this.isMilitaryTime = false;
        this.isTimerRunning = false;
        Timer clockTimer = new Timer(true);
        clockTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                if (!isTimerRunning) {
                    updateClock();
                }
            }
        }, 0, 1000);
    }

    public void setMilitaryTime(boolean isMilitaryTime) {
        this.isMilitaryTime = isMilitaryTime;
        updateClock();
    }

    private void updateClock() {
        LocalTime time = LocalTime.now();
        DateTimeFormatter formatter = isMilitaryTime ? DateTimeFormatter.ofPattern("HH:mm:ss") : DateTimeFormatter.ofPattern("hh:mm:ss a");
        setText(time.format(formatter));
    }

    public void startTimer(int seconds) {
        if (timer != null) {
            timer.cancel();
        }
        timerTime = LocalTime.ofSecondOfDay(seconds);
        isTimerRunning = true;
        timer = new Timer(true);
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                updateTimer();
            }
        }, 0, 1000);
    }

    private void updateTimer() {
        if (timerTime.toSecondOfDay() > 0) {
            timerTime = timerTime.minusSeconds(1);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
            setText(timerTime.format(formatter));
        } else {
            timer.cancel();
            isTimerRunning = false;
        }
    }

    public void stopTimer() {
        if (timer != null) {
            timer.cancel();
        }
        isTimerRunning = false;
    }
}
