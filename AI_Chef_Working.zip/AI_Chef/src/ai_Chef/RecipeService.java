package ai_Chef;

import java.util.ArrayList;
import java.util.List;

public class RecipeService {

    public static List<String> searchRecipes(String query) {
        // Implement the search logic to return matching recipes
        List<String> results = new ArrayList<>();
        // Dummy data for demonstration
        results.add("Spaghetti Bolognese");
        results.add("Chicken Alfredo");
        return results;
    }

    public static String getRecipeDetails(String recipeName) {
        // Implement the logic to return the recipe details
        // Dummy data for demonstration
        if ("Spaghetti Bolognese".equals(recipeName)) {
            return "Ingredients:\n- Spaghetti\n- Ground Beef\n- Tomato Sauce\n\nInstructions:\n1. Cook spaghetti.\n2. Prepare sauce.\n3. Mix and serve.";
        } else if ("Chicken Alfredo".equals(recipeName)) {
            return "Ingredients:\n- Fettuccine\n- Chicken Breast\n- Alfredo Sauce\n\nInstructions:\n1. Cook fettuccine.\n2. Prepare chicken.\n3. Mix with sauce and serve.";
        }
        return "Recipe details not found.";
    }
    
    public static List<String> suggestRecipes(String ingredients) {
        // Implement the logic to suggest recipes based on the provided ingredients
        List<String> suggestions = new ArrayList<>();
        // Dummy data for demonstration
        suggestions.add("Vegetable Stir Fry");
        suggestions.add("Chicken Soup");
        return suggestions;
    }

}
