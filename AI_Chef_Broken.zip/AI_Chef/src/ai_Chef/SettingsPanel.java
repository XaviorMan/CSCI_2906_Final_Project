package ai_Chef;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class SettingsPanel extends JPanel {
    private static final long serialVersionUID = 1L;
    private ClockAndTimer clockAndTimer;
    private JPanel mainPanel;

    public SettingsPanel(ClockAndTimer clockAndTimer) {
        this.clockAndTimer = clockAndTimer;
        setLayout(new BorderLayout());

        mainPanel = new JPanel(new BorderLayout());
        JButton clockSettingsButton = new JButton("Clock and Timer Settings");
        mainPanel.add(clockSettingsButton, BorderLayout.CENTER);
        add(mainPanel, BorderLayout.CENTER);

        clockSettingsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showClockSettingsPanel();
            }
        });
    }

    private void showClockSettingsPanel() {
        removeAll();
        JPanel clockSettingsPanel = createClockSettingsPanel();
        add(clockSettingsPanel, BorderLayout.CENTER);

        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int response = JOptionPane.showConfirmDialog(SettingsPanel.this, "Do you want to save changes before going back?", "Confirm", JOptionPane.YES_NO_CANCEL_OPTION);
                if (response == JOptionPane.YES_OPTION) {
                    // Save changes and go back
                    resetToMainPanel();
                } else if (response == JOptionPane.NO_OPTION) {
                    // Discard changes and go back
                    resetToMainPanel();
                }
                // If CANCEL_OPTION, do nothing
            }
        });

        JButton resetButton = new JButton("Reset to Default");
        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Reset settings to default
                clockAndTimer.setTime(LocalTime.now());
                clockAndTimer.setMilitaryTime(false);
            }
        });

        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.add(resetButton);
        bottomPanel.add(backButton);
        add(bottomPanel, BorderLayout.SOUTH);

        revalidate();
        repaint();
    }

    private void resetToMainPanel() {
        removeAll();
        add(mainPanel, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    private JPanel createClockSettingsPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(2, 1));

        JPanel timeFormatPanel = new JPanel();
        timeFormatPanel.setBorder(BorderFactory.createTitledBorder("Time Format"));
        JRadioButton standardTimeButton = new JRadioButton("Standard Time");
        JRadioButton militaryTimeButton = new JRadioButton("Military Time");
        ButtonGroup timeFormatGroup = new ButtonGroup();
        timeFormatGroup.add(standardTimeButton);
        timeFormatGroup.add(militaryTimeButton);
        standardTimeButton.setSelected(true);
        timeFormatPanel.add(standardTimeButton);
        timeFormatPanel.add(militaryTimeButton);

        JPanel setTimePanel = new JPanel();
        setTimePanel.setBorder(BorderFactory.createTitledBorder("Set Time"));
        JButton setTimeButton = new JButton("Set Time");
        setTimePanel.add(setTimeButton);

        setTimeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String timeString = JOptionPane.showInputDialog(SettingsPanel.this, "Enter time (HH:mm:ss):", LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
                try {
                    LocalTime newTime = LocalTime.parse(timeString, DateTimeFormatter.ofPattern("HH:mm:ss"));
                    clockAndTimer.setTime(newTime);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(SettingsPanel.this, "Invalid time format. Please use HH:mm:ss.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        standardTimeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clockAndTimer.setMilitaryTime(false);
            }
        });

        militaryTimeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clockAndTimer.setMilitaryTime(true);
            }
        });

        panel.add(timeFormatPanel);
        panel.add(setTimePanel);

        return panel;
    }
}
