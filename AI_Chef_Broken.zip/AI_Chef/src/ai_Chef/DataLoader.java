package ai_Chef;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class DataLoader {
    
    // Create tables
    public static void createTables() {
        String createIngredientsTable = "CREATE TABLE IF NOT EXISTS ingredients ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "name TEXT NOT NULL,"
                + "category TEXT NOT NULL"
                + ");";

        String createNutritionalInfoTable = "CREATE TABLE IF NOT EXISTS nutritional_info ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "ingredient_id INTEGER,"
                + "nutrient_name TEXT NOT NULL,"
                + "amount REAL,"
                + "unit TEXT,"
                + "FOREIGN KEY (ingredient_id) REFERENCES ingredients(id)"
                + ");";

        String createRecipesTable = "CREATE TABLE IF NOT EXISTS recipes ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "name TEXT NOT NULL,"
                + "ingredients TEXT,"
                + "instructions TEXT"
                + ");";

        try (Connection conn = DatabaseManager.connect();
                Statement stmt = conn.createStatement()) {
               stmt.execute(sqlIngredients);
               stmt.execute(sqlNutritionalInfo);
               stmt.execute(sqlRecipes);
           } catch (SQLException e) {
               System.out.println(e.getMessage());
           }
    }

    // Load data from CSV files
    public static void loadCSVData(String ingredientsFile, String nutritionalInfoFile) {
        String line;
        try (Connection conn = DatabaseManager.connect();
             Statement stmt = conn.createStatement()) {
            BufferedReader br = new BufferedReader(new FileReader(ingredientsFile));
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                String sql = "INSERT INTO ingredients (name, category) VALUES ('" + values[0] + "', '" + values[1] + "')";
                stmt.execute(sql);
            }
            br.close();

            br = new BufferedReader(new FileReader(nutritionalInfoFile));
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                String sql = "INSERT INTO nutritional_info (ingredient_id, nutrient_name, amount, unit) VALUES ("
                        + values[0] + ", '" + values[1] + "', " + values[2] + ", '" + values[3] + "')";
                stmt.execute(sql);
            }
            br.close();
        } catch (IOException | SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // Load data from JSON file
    public static void loadJSONData(String jsonFile) {
        try (Connection conn = DatabaseManager.connect();
             Statement stmt = conn.createStatement();
             InputStream is = Files.newInputStream(Paths.get(jsonFile))) {

            JSONTokener tokener = new JSONTokener(is);
            JSONArray recipes = new JSONArray(tokener);

            for (int i = 0; i < recipes.length(); i++) {
                JSONObject recipe = recipes.getJSONObject(i);
                String name = recipe.getString("name");
                String ingredients = recipe.getJSONArray("ingredients").toString();
                String instructions = recipe.getString("instructions");

                String sql = "INSERT INTO recipes (name, ingredients, instructions) VALUES ('" + name + "', '" + ingredients + "', '" + instructions + "')";
                stmt.execute(sql);
            }
        } catch (IOException | SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        createTables();
        loadCSVData("path/to/FoodData_Central_Foundation_Food_csv_2024-04-18.csv", "path/to/FoodData_Central_sr_legacy_food_csv_2018-04.csv");
        loadJSONData("src/ai_Chef/resources/datasets/recipe-ingredients-dataset-metadata.json");
    }
}
