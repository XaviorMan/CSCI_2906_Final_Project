package ai_Chef;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class JSONReader {
    public static JSONObject readJSONObject(String filePath) {
        try (InputStream is = Files.newInputStream(Paths.get(filePath))) {
            JSONTokener tokener = new JSONTokener(is);
            return new JSONObject(tokener);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static JSONArray readJSONArray(String filePath) {
        try (InputStream is = Files.newInputStream(Paths.get(filePath))) {
            JSONTokener tokener = new JSONTokener(is);
            return new JSONArray(tokener);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
