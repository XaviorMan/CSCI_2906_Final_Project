package ai_Chef.csv;


import com.opencsv.CSVWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class CSVWriterExample {
    public static void writeCSV(String csvFile, List<String[]> data) {
        try (CSVWriter writer = new CSVWriter(new FileWriter(csvFile))) {
            for (String[] row : data) {
                writer.writeNext(row);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
