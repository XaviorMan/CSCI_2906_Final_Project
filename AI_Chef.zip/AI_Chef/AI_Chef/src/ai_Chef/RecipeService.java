package ai_Chef;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RecipeService {
    public List<String> searchRecipes(String query) {
        String sql = "SELECT name FROM recipes WHERE name LIKE ?";
        List<String> results = new ArrayList<>();

        try (Connection conn = DatabaseManager.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, "%" + query + "%");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                results.add(rs.getString("name"));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return results;
    }

    public String getRecipeDetails(String recipeName) {
        String sql = "SELECT * FROM recipes WHERE name = ?";
        StringBuilder details = new StringBuilder();

        try (Connection conn = DatabaseManager.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, recipeName);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                details.append("Name: ").append(rs.getString("name")).append("\n");
                details.append("Ingredients: ").append(rs.getString("ingredients")).append("\n");
                details.append("Instructions: ").append(rs.getString("instructions")).append("\n");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return details.toString();
    }

    public List<String> suggestRecipes(String ingredients) {
        // Placeholder logic for suggesting recipes based on available ingredients
        List<String> suggestedRecipes = new ArrayList<>();
        String sql = "SELECT name FROM recipes WHERE ingredients LIKE ?";
        
        try (Connection conn = DatabaseManager.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, "%" + ingredients + "%");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                suggestedRecipes.add(rs.getString("name"));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return suggestedRecipes;
    }

    public List<Recipe> searchRecipe(String query) {
        String sql = "SELECT * FROM recipes WHERE name LIKE ?";
        List<Recipe> results = new ArrayList<>();

        try (Connection conn = DatabaseManager.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, "%" + query + "%");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Recipe recipe = new Recipe(rs.getString("name"), rs.getString("ingredients"), rs.getString("instructions"));
                results.add(recipe);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return results;
    }
}
