package ai_Chef;

import javax.swing.JLabel;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Timer;
import java.util.TimerTask;

public class ClockAndTimer extends JLabel {
    private static final long serialVersionUID = 1L;
    private boolean isMilitaryTime = false;
    private DateTimeFormatter standardFormatter = DateTimeFormatter.ofPattern("hh:mm:ss a");
    private DateTimeFormatter militaryFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
    private Timer timer;
    
    public ClockAndTimer() {
        startClock();
    }
    
    private void startClock() {
        timer = new Timer(true);
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                LocalTime currentTime = LocalTime.now();
                setText(currentTime.format(isMilitaryTime ? militaryFormatter : standardFormatter));
            }
        }, 0, 1000);
    }

    public void setTime(LocalTime time) {
        setText(time.format(isMilitaryTime ? militaryFormatter : standardFormatter));
    }

    public void setMilitaryTime(boolean isMilitary) {
        this.isMilitaryTime = isMilitary;
        LocalTime currentTime = LocalTime.now();
        setTime(currentTime);
    }
    
    public void startStopwatch() {
        // Implement stopwatch functionality
    }
    
    public void startCountdown(LocalTime targetTime) {
        // Implement countdown functionality
    }

    // Other timer functions
}
