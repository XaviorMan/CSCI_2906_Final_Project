package ai_Chef;
import javax.swing.*;

import java.awt.*;

public class AI_ChefApp {
    public static void main(String[] args) {
    	
    	DataLoader.createTables();
    	DataLoader.loadCSVData("path/to/ingredients.csv", "path/to/nutritional/info.csv");
    	DataLoader.loadJSONData("src/ai_Chef/resources/datasets/recipe-ingredients-dataset-metadata.json");
    	
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("AI Chef");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(1200, 800);
            frame.setLayout(new BorderLayout());

            // Create an instance of ClockAndTimer
            ClockAndTimer clockAndTimer = new ClockAndTimer();

            // Navigation panel
            NavigationPanel navigationPanel = new NavigationPanel(clockAndTimer);
            frame.add(navigationPanel, BorderLayout.NORTH);

            // Main content area
            JPanel mainPanel = new JPanel(new CardLayout());
            HomePanel homePanel = new HomePanel();
            FridgePanel fridgePanel = new FridgePanel();
            RecipePanel recipesPanel = new RecipePanel();
            SettingsPanel settingsPanel = new SettingsPanel(clockAndTimer);

            mainPanel.add(homePanel, "Home");
            mainPanel.add(fridgePanel, "Fridge");
            mainPanel.add(recipesPanel, "Recipes");
            mainPanel.add(settingsPanel, "Settings");

            frame.add(mainPanel, BorderLayout.CENTER);

            // Pass the CardLayout and mainPanel to the NavigationPanel
            navigationPanel.setMainPanel(mainPanel);

            frame.setVisible(true);
        });
    }
}
