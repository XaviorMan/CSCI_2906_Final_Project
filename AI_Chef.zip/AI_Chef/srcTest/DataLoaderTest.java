/*

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import ai_Chef.DatabaseManager;
import ai_Chef.DataLoader;

public class DataLoaderTest {

    @Before
    public void setUp() {
        DataLoader.createTables();
    }

    @Test
    public void testCreateTables() {
        try (Connection conn = DatabaseManager.connect();
             Statement stmt = conn.createStatement()) {
            ResultSet rs = stmt.executeQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='ingredients'");
            Assert.assertTrue(rs.next());

            rs = stmt.executeQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='nutritional_info'");
            Assert.assertTrue(rs.next());

            rs = stmt.executeQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='recipes'");
            Assert.assertTrue(rs.next());
        } catch (SQLException e) {
            Assert.fail(e.getMessage());
        }
    }

    @Test
    public void testLoadCSVData() {
        DataLoader.loadCSVData("path/to/FoodData_Central_Foundation_Food_csv_2024-04-18.csv", "path/to/FoodData_Central_sr_legacy_food_csv_2018-04.csv");

        try (Connection conn = DatabaseManager.connect();
             Statement stmt = conn.createStatement()) {
            ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS count FROM ingredients");
            rs.next();
            int count = rs.getInt("count");
            Assert.assertTrue(count > 0);

            rs = stmt.executeQuery("SELECT COUNT(*) AS count FROM nutritional_info");
            rs.next();
            count = rs.getInt("count");
            Assert.assertTrue(count > 0);
        } catch (SQLException e) {
            Assert.fail(e.getMessage());
        }
    }

    @Test
    public void testLoadJSONData() {
        DataLoader.loadJSONData("src/ai_Chef/resources/datasets/recipe-ingredients-dataset-metadata.json");

        try (Connection conn = DatabaseManager.connect();
             Statement stmt = conn.createStatement()) {
            ResultSet rs = stmt.executeQuery("SELECT COUNT(*) AS count FROM recipes");
            rs.next();
            int count = rs.getInt("count");
            Assert.assertTrue(count > 0);
        } catch (SQLException e) {
            Assert.fail(e.getMessage());
        }
    }
}
*/