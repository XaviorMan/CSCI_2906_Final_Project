import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class FridgePanel extends JPanel {
    private static final long serialVersionUID = 1L;
    private JPanel dynamicPanel;
    private JLabel sectionTitle;
    private JPanel itemsListPanel;
    private JTextField newItemField;
    private JButton addItemButton;
    private JButton bulkAddButton;
    private JTextField searchField;
    private Map<String, Map<String, Integer>> storageData; // Use a Map to store items and their quantities

    public FridgePanel() {
        setLayout(new BorderLayout());

        // Initialize storage data
        storageData = new HashMap<>();
        storageData.put("Fridge", new HashMap<>());
        storageData.put("Freezer", new HashMap<>());
        storageData.put("Spice Cabinet", new HashMap<>());
        storageData.put("Pantry", new HashMap<>());
        storageData.put("Deep Freezer", new HashMap<>());

        // Left Panel with GridLayout
        JPanel leftPanel = new JPanel(new GridLayout(2, 5));

        // Freezer (First Row, Column 1)
        JPanel freezerPanel = createSectionPanel("Freezer");
        leftPanel.add(freezerPanel);

        // Empty Cells for the rest of the first row except last column
        leftPanel.add(new JLabel(""));
        leftPanel.add(new JLabel(""));
        leftPanel.add(new JLabel(""));

        // Search Field (First Row, Column 5)
        searchField = new JTextField();
        searchField.setBorder(BorderFactory.createTitledBorder("Search Items"));
        searchField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateItemsList(sectionTitle.getText().split(" ")[0], searchField.getText());
            }
        });
        leftPanel.add(searchField);

        // Second Row
        JPanel fridgePanel = createSectionPanel("Fridge");
        leftPanel.add(fridgePanel);

        JPanel spiceCabinetPanel = createSectionPanel("Spice Cabinet");
        leftPanel.add(spiceCabinetPanel);

        JPanel pantryPanel = createSectionPanel("Pantry");
        leftPanel.add(pantryPanel);

        JPanel deepFreezerPanel = createSectionPanel("Deep Freezer");
        leftPanel.add(deepFreezerPanel);

        add(leftPanel, BorderLayout.CENTER);

        // Right Panel (Dynamic Panel)
        dynamicPanel = new JPanel(new BorderLayout());
        sectionTitle = new JLabel("Select a section", SwingConstants.CENTER);
        itemsListPanel = new JPanel();
        itemsListPanel.setLayout(new BoxLayout(itemsListPanel, BoxLayout.Y_AXIS));

        newItemField = new JTextField();
        addItemButton = new JButton("Add Item");
        bulkAddButton = new JButton("Bulk Add");

        addItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedSection = sectionTitle.getText().split(" ")[0];
                String newItem = newItemField.getText();
                if (!newItem.isEmpty() && storageData.containsKey(selectedSection)) {
                    addItem(selectedSection, newItem, 1);
                    updateItemsList(selectedSection);
                    newItemField.setText("");
                }
            }
        });

        bulkAddButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedSection = JOptionPane.showInputDialog(FridgePanel.this, "Enter section (Fridge, Freezer, Spice Cabinet, Pantry, Deep Freezer):", "Bulk Add", JOptionPane.PLAIN_MESSAGE);
                if (selectedSection != null && storageData.containsKey(selectedSection)) {
                    String bulkItems = JOptionPane.showInputDialog(FridgePanel.this, "Enter items (quantity item):", "Bulk Add", JOptionPane.PLAIN_MESSAGE);
                    if (bulkItems != null && !bulkItems.isEmpty()) {
                        String[] parts = bulkItems.split(" ", 2);
                        int quantity = Integer.parseInt(parts[0].trim());
                        String itemName = parts[1].trim();
                        addItem(selectedSection, itemName, quantity);
                        updateItemsList(selectedSection);
                    }
                }
            }
        });

        dynamicPanel.add(sectionTitle, BorderLayout.NORTH);
        dynamicPanel.add(new JScrollPane(itemsListPanel), BorderLayout.CENTER);

        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.add(newItemField, BorderLayout.CENTER);
        inputPanel.add(addItemButton, BorderLayout.EAST);

        JPanel bulkPanel = new JPanel(new BorderLayout());
        bulkPanel.add(bulkAddButton, BorderLayout.CENTER);

        dynamicPanel.add(inputPanel, BorderLayout.SOUTH);
        dynamicPanel.add(bulkPanel, BorderLayout.NORTH);

        add(dynamicPanel, BorderLayout.EAST);
        dynamicPanel.setPreferredSize(new Dimension(300, getHeight())); // Adjust width as needed
    }

    private JPanel createSectionPanel(String sectionName) {
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createTitledBorder(sectionName));
        panel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        panel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sectionTitle.setText(sectionName + " Ingredients");
                updateItemsList(sectionName);
            }
        });
        return panel;
    }

    private void updateItemsList(String sectionName) {
        updateItemsList(sectionName, "");
    }

    private void updateItemsList(String sectionName, String filter) {
        Map<String, Integer> items = storageData.get(sectionName);
        itemsListPanel.removeAll();
        for (Map.Entry<String, Integer> entry : items.entrySet()) {
            String itemName = entry.getKey();
            int quantity = entry.getValue();
            if (filter.isEmpty() || itemName.contains(filter)) {
                JPanel itemPanel = new JPanel(new BorderLayout());
                JLabel itemLabel = new JLabel(itemName + " (" + quantity + ")");
                JButton incrementButton = new JButton("+");
                JButton decrementButton = new JButton("-");

                incrementButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        addItem(sectionName, itemName, 1);
                        updateItemsList(sectionName);
                    }
                });

                decrementButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        removeItem(sectionName, itemName);
                        updateItemsList(sectionName);
                    }
                });

                itemPanel.add(itemLabel, BorderLayout.CENTER);
                JPanel buttonPanel = new JPanel(new GridLayout(1, 2));
                buttonPanel.add(incrementButton);
                buttonPanel.add(decrementButton);
                itemPanel.add(buttonPanel, BorderLayout.EAST);
                itemsListPanel.add(itemPanel);
            }
        }
        itemsListPanel.revalidate();
        itemsListPanel.repaint();
    }

    private void addItem(String sectionName, String itemName, int quantity) {
        Map<String, Integer> items = storageData.get(sectionName);
        items.put(itemName, items.getOrDefault(itemName, 0) + quantity);
    }

    private void removeItem(String sectionName, String itemName) {
        Map<String, Integer> items = storageData.get(sectionName);
        if (items.containsKey(itemName)) {
            int quantity = items.get(itemName);
            if (quantity > 1) {
                items.put(itemName, quantity - 1);
            } else {
                items.remove(itemName);
            }
        }
    }
}
