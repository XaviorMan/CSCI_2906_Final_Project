package AI_Chef.data;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class DataCleaner {
    public static List<String[]> cleanData(List<String[]> data) {
        Set<String> uniqueRows = new HashSet<>();
        Iterator<String[]> iterator = data.iterator();

        while (iterator.hasNext()) {
            String[] row = iterator.next();

            // Remove duplicates
            String rowString = String.join(",", row);
            if (!uniqueRows.add(rowString)) {
                iterator.remove();
                continue;
            }

            // Handle missing values
            for (int i = 0; i < row.length; i++) {
                if (row[i] == null || row[i].isEmpty()) {
                    row[i] = "N/A"; // Example: fill missing values with "N/A"
                }
            }

            // Validate data types (Example: Ensure numeric fields contain numbers)
            if (row.length > 2) { // Ensure the row has at least 3 columns
                try {
                    Double.parseDouble(row[2]); // Assuming column 3 should be numeric
                } catch (NumberFormatException e) {
                    row[2] = "0"; // Example: replace invalid numbers with 0
                }
            }
        }
        return data;
    }
}
