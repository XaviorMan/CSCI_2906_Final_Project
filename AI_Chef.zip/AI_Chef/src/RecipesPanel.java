import javax.swing.*;
import java.awt.*;

public class RecipesPanel extends JPanel {
    private static final long serialVersionUID = 1L; // Adding serialVersionUID

    public RecipesPanel() {
        setLayout(new BorderLayout());
        
        JLabel recipesLabel = new JLabel("Recipes");
        add(recipesLabel, BorderLayout.CENTER);
    }
}
