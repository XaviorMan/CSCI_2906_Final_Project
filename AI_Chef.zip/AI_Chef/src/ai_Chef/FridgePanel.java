package ai_Chef;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class FridgePanel extends JPanel {
	private static final long serialVersionUID = 1L;
	
    private JTextField nameField;
    private JTextField categoryField;
    private JTextField quantityField;
    private JButton addButton;
    private JButton saveButton;
    private JButton loadButton;
    private JList<Ingredient> inventoryList;
    private DefaultListModel<Ingredient> inventoryListModel;

    private DatabaseManager databaseManager;

    public FridgePanel() {
        databaseManager = new DatabaseManager();

        setLayout(new BorderLayout());

        // Input panel
        JPanel inputPanel = new JPanel(new GridLayout(4, 2));
        inputPanel.add(new JLabel("Ingredient Name:"));
        nameField = new JTextField();
        inputPanel.add(nameField);

        inputPanel.add(new JLabel("Category:"));
        categoryField = new JTextField();
        inputPanel.add(categoryField);

        inputPanel.add(new JLabel("Quantity:"));
        quantityField = new JTextField();
        inputPanel.add(quantityField);

        addButton = new JButton("Add Ingredient");
        inputPanel.add(addButton);

        saveButton = new JButton("Save Inventory");
        inputPanel.add(saveButton);

        loadButton = new JButton("Load Inventory");
        inputPanel.add(loadButton);

        add(inputPanel, BorderLayout.NORTH);

        // Inventory list
        inventoryListModel = new DefaultListModel<>();
        inventoryList = new JList<>(inventoryListModel);
        add(new JScrollPane(inventoryList), BorderLayout.CENTER);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addIngredient();
            }
        });

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveInventory();
            }
        });

        loadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadInventory();
            }
        });
    }

    private void addIngredient() {
        String name = nameField.getText();
        String category = categoryField.getText();
        String quantityText = quantityField.getText();

        if (name.isEmpty() || category.isEmpty() || quantityText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            double quantity = Double.parseDouble(quantityText);
            Ingredient ingredient = new Ingredient(name, category, quantity);
            inventoryListModel.addElement(ingredient);
            clearFields();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number for quantity", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    private void clearFields() {
        nameField.setText("");
        categoryField.setText("");
        quantityField.setText("");
    }

    private void saveInventory() {
        List<Ingredient> inventory = new ArrayList<>();
        for (int i = 0; i < inventoryListModel.getSize(); i++) {
            inventory.add(inventoryListModel.getElementAt(i));
        }
        databaseManager.saveInventory(inventory);
    }

    private void loadInventory() {
        List<Ingredient> inventory = databaseManager.loadInventory();
        inventoryListModel.clear();
        for (Ingredient ingredient : inventory) {
            inventoryListModel.addElement(ingredient);
        }
    }
}
