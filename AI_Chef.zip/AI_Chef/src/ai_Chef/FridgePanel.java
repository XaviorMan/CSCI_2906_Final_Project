package ai_Chef;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FridgePanel extends JPanel {
    private static final long serialVersionUID = 1L;
    private JPanel dynamicPanel;
    private JLabel sectionTitle;
    private JPanel itemsListPanel;
    private JTextField newItemField;
    private JButton addItemButton;
    private JButton bulkAddButton;
    private JTextField searchField;
    private Map<String, Map<String, Integer>> storageData;
    private JTextField ingredientField;
    private JButton suggestButton;
    private JList<String> suggestedRecipesList;
    private DefaultListModel<String> listModel;

    private static final String[] PERSON_ONE_ITEMS = {
        // Freezer items
        "Frozen Peas", "Frozen Corn", "Ice Cream", "Frozen Pizza", "Frozen Chicken", 
        "Frozen Berries",
        // Fridge items
        "Milk", "Eggs", "Cheese", "Butter", "Yogurt", "Lettuce", "Tomatoes",
        // Spice Cabinet items
        "Salt", "Pepper", "Cumin", "Paprika", "Oregano", "Garlic Powder",
        // Pantry items
        "Pasta", "Rice", "Canned Beans", "Flour", "Sugar", "Olive Oil",
        // Deep Freezer items
        "Frozen Beef", "Frozen Fish", "Frozen Vegetables"
    };

    private static final String[] PERSON_TWO_ITEMS = {
        // Freezer items
        "Frozen Broccoli", "Frozen Green Beans", "Frozen Pizza", "Frozen Chicken Wings", "Ice Cream",
        "Frozen Strawberries", "Frozen Blueberries",
        // Fridge items
        "Milk", "Eggs", "Cheese", "Butter", "Yogurt", "Carrots", "Bell Peppers", "Spinach",
        // Spice Cabinet items
        "Salt", "Black Pepper", "Cinnamon", "Turmeric", "Chili Powder", "Basil", "Thyme",
        // Pantry items
        "Pasta", "Rice", "Canned Tomatoes", "Canned Corn", "Flour", "Brown Sugar", "Vegetable Oil",
        // Deep Freezer items
        "Frozen Pork", "Frozen Shrimp", "Frozen Mixed Vegetables", "Frozen Sausages"
    };

    public FridgePanel() {
        setLayout(new BorderLayout());

        // Initialize storage data
        storageData = new HashMap<>();
        storageData.put("Fridge", new HashMap<>());
        storageData.put("Freezer", new HashMap<>());
        storageData.put("Spice Cabinet", new HashMap<>());
        storageData.put("Pantry", new HashMap<>());
        storageData.put("Deep Freezer", new HashMap<>());

        // Left Panel with GridLayout
        JPanel leftPanel = new JPanel(new GridLayout(2, 5));

        // Freezer (First Row, Column 1)
        JPanel freezerPanel = createSectionPanel("Freezer");
        leftPanel.add(freezerPanel);

        // Empty Cells for the rest of the first row except last column
        leftPanel.add(new JLabel(""));
        leftPanel.add(new JLabel(""));
        leftPanel.add(new JLabel(""));

        // Search Field (First Row, Column 5)
        searchField = new JTextField();
        searchField.setBorder(BorderFactory.createTitledBorder("Search Items"));
        searchField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateItemsList(sectionTitle.getText().split(" ")[0], searchField.getText());
            }
        });
        leftPanel.add(searchField);

        // Second Row
        JPanel fridgePanel = createSectionPanel("Fridge");
        leftPanel.add(fridgePanel);

        JPanel spiceCabinetPanel = createSectionPanel("Spice Cabinet");
        leftPanel.add(spiceCabinetPanel);

        JPanel pantryPanel = createSectionPanel("Pantry");
        leftPanel.add(pantryPanel);

        JPanel deepFreezerPanel = createSectionPanel("Deep Freezer");
        leftPanel.add(deepFreezerPanel);

        add(leftPanel, BorderLayout.CENTER);

        // Right Panel (Dynamic Panel)
        dynamicPanel = new JPanel(new BorderLayout());
        sectionTitle = new JLabel("Select a section", SwingConstants.CENTER);
        itemsListPanel = new JPanel();
        itemsListPanel.setLayout(new BoxLayout(itemsListPanel, BoxLayout.Y_AXIS));

        newItemField = new JTextField();
        addItemButton = new JButton("Add Item");
        bulkAddButton = new JButton("Bulk Add");

        addItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedSection = sectionTitle.getText().split(" ")[0];
                String newItem = newItemField.getText();
                if (!newItem.isEmpty() && storageData.containsKey(selectedSection)) {
                    addItem(selectedSection, newItem, 1);
                    updateItemsList(selectedSection);
                    newItemField.setText("");
                }
            }
        });

        bulkAddButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedSection = JOptionPane.showInputDialog(FridgePanel.this, "Enter section (Fridge, Freezer, Spice Cabinet, Pantry, Deep Freezer):", "Bulk Add", JOptionPane.PLAIN_MESSAGE);
                if (selectedSection != null && storageData.containsKey(selectedSection)) {
                    String bulkItems = JOptionPane.showInputDialog(FridgePanel.this, "Enter items (quantity item):", "Bulk Add", JOptionPane.PLAIN_MESSAGE);
                    if (bulkItems != null && !bulkItems.isEmpty()) {
                        String[] parts = bulkItems.split(" ", 2);
                        int quantity = Integer.parseInt(parts[0].trim());
                        String itemName = parts[1].trim();
                        addItem(selectedSection, itemName, quantity);
                        updateItemsList(selectedSection);
                    }
                }
            }
        });

        dynamicPanel.add(sectionTitle, BorderLayout.NORTH);
        dynamicPanel.add(new JScrollPane(itemsListPanel), BorderLayout.CENTER);

        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.add(newItemField, BorderLayout.CENTER);
        inputPanel.add(addItemButton, BorderLayout.EAST);

        JPanel bulkPanel = new JPanel(new BorderLayout());
        bulkPanel.add(bulkAddButton, BorderLayout.CENTER);

        dynamicPanel.add(inputPanel, BorderLayout.SOUTH);
        dynamicPanel.add(bulkPanel, BorderLayout.NORTH);

        add(dynamicPanel, BorderLayout.EAST);
        dynamicPanel.setPreferredSize(new Dimension(300, getHeight()));

        // Buttons for Person One and Person Two
        JButton personOneButton = new JButton("Person One");
        personOneButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                populateItems(PERSON_ONE_ITEMS);
            }
        });

        JButton personTwoButton = new JButton("Person Two");
        personTwoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                populateItems(PERSON_TWO_ITEMS);
            }
        });

        // Panel for person buttons
        JPanel personPanel = new JPanel(new GridLayout(1, 2));
        personPanel.add(personOneButton);
        personPanel.add(personTwoButton);
        add(personPanel, BorderLayout.SOUTH);

        // Ingredient Input Panel for suggesting recipes
        JPanel suggestPanel = new JPanel();
        ingredientField = new JTextField(20);
        suggestButton = new JButton("Suggest Recipes");
        suggestPanel.add(new JLabel("Enter ingredients:"));
        suggestPanel.add(ingredientField);
        suggestPanel.add(suggestButton);

        // Suggested Recipes List
        listModel = new DefaultListModel<>();
        suggestedRecipesList = new JList<>(listModel);
        JScrollPane scrollPane = new JScrollPane(suggestedRecipesList);

        // Add Components
        add(suggestPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.SOUTH);

        // Event Listeners
        suggestButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String ingredients = ingredientField.getText();
                suggestRecipes(ingredients);
            }
        });
    }

    private JPanel createSectionPanel(String sectionName) {
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createTitledBorder(sectionName));
        panel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        panel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sectionTitle.setText(sectionName + " Ingredients");
                updateItemsList(sectionName);
            }
        });
        return panel;
    }

    private void updateItemsList(String sectionName) {
        updateItemsList(sectionName, "");
    }

    private void updateItemsList(String sectionName, String filter) {
        Map<String, Integer> items = storageData.get(sectionName);
        itemsListPanel.removeAll();
        for (Map.Entry<String, Integer> entry : items.entrySet()) {
            String itemName = entry.getKey();
            int quantity = entry.getValue();
            if (filter.isEmpty() || itemName.contains(filter)) {
                JPanel itemPanel = new JPanel(new BorderLayout());
                JLabel itemLabel = new JLabel(itemName + " (" + quantity + ")");
                JButton incrementButton = new JButton("+");
                JButton decrementButton = new JButton("-");

                incrementButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        addItem(sectionName, itemName, 1);
                        updateItemsList(sectionName);
                    }
                });

                decrementButton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        removeItem(sectionName, itemName);
                        updateItemsList(sectionName);
                    }
                });

                itemPanel.add(itemLabel, BorderLayout.CENTER);
                JPanel buttonPanel = new JPanel(new GridLayout(1, 2));
                buttonPanel.add(incrementButton);
                buttonPanel.add(decrementButton);
                itemPanel.add(buttonPanel, BorderLayout.EAST);
                itemsListPanel.add(itemPanel);
            }
        }
        itemsListPanel.revalidate();
        itemsListPanel.repaint();
    }

    private void addItem(String sectionName, String itemName, int quantity) {
        Map<String, Integer> items = storageData.get(sectionName);
        items.put(itemName, items.getOrDefault(itemName, 0) + quantity);
    }

    private void removeItem(String sectionName, String itemName) {
        Map<String, Integer> items = storageData.get(sectionName);
        if (items.containsKey(itemName)) {
            int quantity = items.get(itemName);
            if (quantity > 1) {
                items.put(itemName, quantity - 1);
            } else {
                items.remove(itemName);
            }
        }
    }

    private void populateItems(String[] items) {
        clearAllSections();
        int i = 0;
        for (; i < 6; i++) {
            addItem("Freezer", items[i], 1);
        }
        for (; i < 13; i++) {
            addItem("Fridge", items[i], 1);
        }
        for (; i < 19; i++) {
            addItem("Spice Cabinet", items[i], 1);
        }
        for (; i < 25; i++) {
            addItem("Pantry", items[i], 1);
        }
        for (; i < items.length; i++) {
            addItem("Deep Freezer", items[i], 1);
        }
        updateAllSections();
    }

    private void clearAllSections() {
        for (Map<String, Integer> section : storageData.values()) {
            section.clear();
        }
    }

    private void updateAllSections() {
        updateItemsList("Freezer");
        updateItemsList("Fridge");
        updateItemsList("Spice Cabinet");
        updateItemsList("Pantry");
        updateItemsList("Deep Freezer");
    }

    private void suggestRecipes(String ingredients) {
        RecipeService recipeService = new RecipeService();
        List<String> suggestions = recipeService.suggestRecipes(ingredients);
        listModel.clear();
        for (String recipe : suggestions) {
            listModel.addElement(recipe);
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Fridge Panel");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new FridgePanel());
        frame.setSize(800, 600);
        frame.setVisible(true);
    }
}
