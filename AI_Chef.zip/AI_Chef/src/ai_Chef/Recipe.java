package ai_Chef;

import java.util.List;

public class Recipe {
    private String name;
    private List<String> ingredients;
    private String healthInformation;

    // Constructors, getters, and setters
    public Recipe(String name, List<String> ingredients, String healthInformation) {
        this.name = name;
        this.ingredients = ingredients;
        this.healthInformation = healthInformation;
    }

    public String getName() {
        return name;
    }

    public List<String> getIngredients() {
        return ingredients;
    }

    public String getHealthInformation() {
        return healthInformation;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setIngredients(List<String> ingredients) {
        this.ingredients = ingredients;
    }

    public void setHealthInformation(String healthInformation) {
        this.healthInformation = healthInformation;
    }
}
