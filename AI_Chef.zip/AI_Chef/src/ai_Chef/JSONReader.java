package ai_Chef;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;
import java.io.InputStream;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class JSONReader {
    
    // Method to read a file as a string
    public static String readFileAsString(String filePath) throws IOException {
        return new String(Files.readAllBytes(Paths.get(filePath)));
    }
    
    // Method to read a JSON object from a file
    public static JSONObject readJSONObject(String filePath) {
        try (InputStream is = Files.newInputStream(Paths.get(filePath))) {
            JSONTokener tokener = new JSONTokener(is);
            return new JSONObject(tokener);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Method to read a JSON array from a file
    public static JSONArray readJSONArray(String filePath) {
        try (InputStream is = Files.newInputStream(Paths.get(filePath))) {
            JSONTokener tokener = new JSONTokener(is);
            return new JSONArray(tokener);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    // Main method to test the JSONReader functionalities
    public static void main(String[] args) {
        try {
            String filePath = "src/ai_Chef/resources/datasets/json/recipe-ingredients-dataset-metadata.json";
            
            // Read file as string
            String content = readFileAsString(filePath);
            System.out.println("File content as String:");
            System.out.println(content);

            // Read file as JSONObject
            JSONObject jsonObject = readJSONObject(filePath);
            System.out.println("File content as JSONObject:");
            System.out.println(jsonObject.toString(4)); // Pretty print with indentation

            // Read file as JSONArray
            JSONArray jsonArray = readJSONArray(filePath);
            System.out.println("File content as JSONArray:");
            System.out.println(jsonArray.toString(4)); // Pretty print with indentation
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
