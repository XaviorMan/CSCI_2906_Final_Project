package ai_Chef;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseManager {
    public static Connection connect() { 
    	
        // SQLite connection string
        String url = "jdbc:sqlite:ai_chef.db";
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }

    public void saveInventory(List<Ingredient> inventory) {
        String sql = "INSERT INTO ingredients(name, category, quantity) VALUES(?, ?, ?)";

        try (Connection conn = DatabaseManager.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            // Clear existing inventory
            conn.createStatement().execute("DELETE FROM ingredients");

            for (Ingredient ingredient : inventory) {
                pstmt.setString(1, ingredient.getName());
                pstmt.setString(2, ingredient.getCategory());
                pstmt.setDouble(3, ingredient.getQuantity());
                pstmt.executeUpdate();
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public List<Ingredient> loadInventory() {
        String sql = "SELECT name, category, quantity FROM ingredients";
        List<Ingredient> inventory = new ArrayList<>();

        try (Connection conn = DatabaseManager.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Ingredient ingredient = new Ingredient(rs.getString("name"), rs.getString("category"), rs.getDouble("quantity"));
                inventory.add(ingredient);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return inventory;
    }
}
