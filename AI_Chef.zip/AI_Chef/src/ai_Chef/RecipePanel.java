package ai_Chef;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RecipePanel extends JPanel {
    private static final long serialVersionUID = 1L;

    private JTextField recipeNameField;
    private JTextArea ingredientsArea;
    private JTextArea instructionsArea;
    private JTextField searchField;
    private JPanel recipeListPanel;
    private JCheckBox saveRecipeCheckbox;
    private JCheckBox favoriteRecipeCheckbox;
    private JButton longListButton;
    private JButton twoListsButton;

    private List<String> availableIngredients;

    public RecipePanel() {
        setLayout(new BorderLayout());

        // Left panel for favorite and top recipes
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BorderLayout());

        // Favorite recipes panel
        JPanel favoritePanel = new JPanel();
        favoritePanel.setLayout(new BorderLayout());
        favoritePanel.add(new JLabel("Favorite Recipes:"), BorderLayout.NORTH);
        JList<String> favoriteList = new JList<>(new String[]{"Favorite Recipe 1", "Favorite Recipe 2"});
        JScrollPane favoriteScrollPane = new JScrollPane(favoriteList);
        favoritePanel.add(favoriteScrollPane, BorderLayout.CENTER);

        // Top recipes panel
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BorderLayout());
        topPanel.add(new JLabel("Top Recipes:"), BorderLayout.NORTH);
        JList<String> topList = new JList<>(new String[]{"Top Recipe 1", "Top Recipe 2"});
        JScrollPane topScrollPane = new JScrollPane(topList);
        topPanel.add(topScrollPane, BorderLayout.CENTER);

        leftPanel.add(favoritePanel, BorderLayout.NORTH);
        leftPanel.add(topPanel, BorderLayout.SOUTH);

        // Right panel for recipe filters and search
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BorderLayout());

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(5, 1));
        JButton onHandButton = new JButton("On-hand Recipes");
        JButton allRecipesButton = new JButton("All Recipes");
        JButton savedRecipesButton = new JButton("Saved Recipes");
        JButton missing1Button = new JButton("Missing 1 Ingredient");
        JButton missing2Or3Button = new JButton("Missing 2-3 Ingredients");
        buttonPanel.add(onHandButton);
        buttonPanel.add(allRecipesButton);
        buttonPanel.add(savedRecipesButton);
        buttonPanel.add(missing1Button);
        buttonPanel.add(missing2Or3Button);

        searchField = new JTextField();
        JPanel searchPanel = new JPanel();
        searchPanel.setLayout(new BorderLayout());
        searchPanel.add(new JLabel("Search Recipes:"), BorderLayout.NORTH);
        searchPanel.add(searchField, BorderLayout.CENTER);

        rightPanel.add(buttonPanel, BorderLayout.CENTER);
        rightPanel.add(searchPanel, BorderLayout.SOUTH);

        // Middle panel for displaying recipes
        JPanel middlePanel = new JPanel();
        middlePanel.setLayout(new BorderLayout());

        recipeListPanel = new JPanel();
        recipeListPanel.setLayout(new BoxLayout(recipeListPanel, BoxLayout.Y_AXIS));
        JScrollPane recipeScrollPane = new JScrollPane(recipeListPanel);
        middlePanel.add(recipeScrollPane, BorderLayout.CENTER);

        JPanel layoutPanel = new JPanel();
        longListButton = new JButton("Long List");
        twoListsButton = new JButton("Two Lists");
        layoutPanel.add(longListButton);
        layoutPanel.add(twoListsButton);
        middlePanel.add(layoutPanel, BorderLayout.NORTH);

        // Recipe name panel
        JPanel namePanel = new JPanel();
        namePanel.setLayout(new BorderLayout());
        namePanel.add(new JLabel("Recipe Name:"), BorderLayout.WEST);
        recipeNameField = new JTextField();
        recipeNameField.setEditable(false);
        namePanel.add(recipeNameField, BorderLayout.CENTER);

        // Ingredients panel
        JPanel ingredientsPanel = new JPanel();
        ingredientsPanel.setLayout(new BorderLayout());
        ingredientsPanel.add(new JLabel("Ingredients:"), BorderLayout.NORTH);
        ingredientsArea = new JTextArea();
        ingredientsArea.setEditable(false);
        ingredientsArea.setLineWrap(true);
        ingredientsArea.setWrapStyleWord(true);
        JScrollPane ingredientsScrollPane = new JScrollPane(ingredientsArea);
        ingredientsPanel.add(ingredientsScrollPane, BorderLayout.CENTER);

        // Instructions panel
        JPanel instructionsPanel = new JPanel();
        instructionsPanel.setLayout(new BorderLayout());
        instructionsPanel.add(new JLabel("Instructions:"), BorderLayout.NORTH);
        instructionsArea = new JTextArea();
        instructionsArea.setEditable(false);
        instructionsArea.setLineWrap(true);
        instructionsArea.setWrapStyleWord(true);
        JScrollPane instructionsScrollPane = new JScrollPane(instructionsArea);
        instructionsPanel.add(instructionsScrollPane, BorderLayout.CENTER);

        // Checkbox for saving and favoriting recipes
        saveRecipeCheckbox = new JCheckBox("Save Recipe");
        favoriteRecipeCheckbox = new JCheckBox("Favorite Recipe");

        // Add panels to main panel
        JPanel topPanelMain = new JPanel();
        topPanelMain.setLayout(new BorderLayout());
        topPanelMain.add(namePanel, BorderLayout.NORTH);
        topPanelMain.add(ingredientsPanel, BorderLayout.CENTER);
        topPanelMain.add(instructionsPanel, BorderLayout.SOUTH);

        add(leftPanel, BorderLayout.WEST);
        add(middlePanel, BorderLayout.CENTER);
        add(rightPanel, BorderLayout.EAST);
        add(topPanelMain, BorderLayout.NORTH);

        // Checkbox for saving and favoriting recipes
        JPanel checkboxPanel = new JPanel();
        checkboxPanel.setLayout(new FlowLayout());
        checkboxPanel.add(saveRecipeCheckbox);
        checkboxPanel.add(favoriteRecipeCheckbox);
        add(checkboxPanel, BorderLayout.SOUTH);

        // Load available ingredients (mock data for demonstration)
        loadAvailableIngredients();

        // Button actions
        onHandButton.addActionListener(e -> showRecipesByAvailability(0));
        allRecipesButton.addActionListener(e -> showAllRecipes());
        savedRecipesButton.addActionListener(e -> showSavedRecipes());
        missing1Button.addActionListener(e -> showRecipesByAvailability(1));
        missing2Or3Button.addActionListener(e -> showRecipesByAvailability(2));
        longListButton.addActionListener(e -> setRecipeListLayout(1));
        twoListsButton.addActionListener(e -> setRecipeListLayout(2));
    }

    private void loadAvailableIngredients() {
        // Mock data for demonstration
        availableIngredients = Arrays.asList("salt", "pepper", "chicken", "tomato", "lettuce");
    }

    private void showRecipesByAvailability(int missingIngredients) {
        // Mock data for demonstration
        List<Recipe> recipes = loadRecipes();

        recipeListPanel.removeAll();

        for (Recipe recipe : recipes) {
            int missingCount = 0;
            for (String ingredient : recipe.getIngredients()) {
                if (!availableIngredients.contains(ingredient)) {
                    missingCount++;
                }
            }

            if (missingCount <= missingIngredients) {
                JCheckBox recipeCheckBox = new JCheckBox(recipe.getName());
                recipeListPanel.add(recipeCheckBox);
            }
        }

        recipeListPanel.revalidate();
        recipeListPanel.repaint();
    }

    private void showAllRecipes() {
        // Mock data for demonstration
        List<Recipe> recipes = loadRecipes();

        recipeListPanel.removeAll();

        for (Recipe recipe : recipes) {
            JCheckBox recipeCheckBox = new JCheckBox(recipe.getName());
            recipeListPanel.add(recipeCheckBox);
        }

        recipeListPanel.revalidate();
        recipeListPanel.repaint();
    }

    private void showSavedRecipes() {
        // Mock data for demonstration
        List<Recipe> savedRecipes = loadSavedRecipes();

        recipeListPanel.removeAll();

        for (Recipe recipe : savedRecipes) {
            JCheckBox recipeCheckBox = new JCheckBox(recipe.getName());
            recipeListPanel.add(recipeCheckBox);
        }

        recipeListPanel.revalidate();
        recipeListPanel.repaint();
    }

    private void setRecipeListLayout(int layoutType) {
        if (layoutType == 1) {
            recipeListPanel.setLayout(new BoxLayout(recipeListPanel, BoxLayout.Y_AXIS));
        } else if (layoutType == 2) {
            recipeListPanel.setLayout(new GridLayout(0, 2));
        }

        recipeListPanel.revalidate();
        recipeListPanel.repaint();
    }

    private List<Recipe> loadRecipes() {
        // Load recipes from your data source
        List<Recipe> recipes = new ArrayList<>();
        recipes.add(new Recipe("Chicken Salad", Arrays.asList("chicken", "lettuce", "tomato", "salt")));
        recipes.add(new Recipe("Tomato Soup", Arrays.asList("tomato", "salt", "pepper")));
        recipes.add(new Recipe("Grilled Cheese", Arrays.asList("bread", "cheese", "butter")));
        return recipes;
    }

    private List<Recipe> loadSavedRecipes() {
        // Load saved recipes from your data source
        List<Recipe> recipes = new ArrayList<>();
        recipes.add(new Recipe("Chicken Salad", Arrays.asList("chicken", "lettuce", "tomato", "salt")));
        return recipes;
    }

    public void loadRecipe(int recipeId) {
        try (Connection conn = DatabaseManager.connect();
             Statement stmt = conn.createStatement()) {
            String query = "SELECT * FROM recipes WHERE id = " + recipeId;
            ResultSet rs = stmt.executeQuery(query);

            if (rs.next()) {
                recipeNameField.setText(rs.getString("name"));
                ingredientsArea.setText(rs.getString("ingredients"));
                instructionsArea.setText(rs.getString("instructions"));
            } else {
                JOptionPane.showMessageDialog(this, "Recipe not found", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading recipe", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Recipe Panel");
        RecipePanel recipePanel = new RecipePanel();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(recipePanel);
        frame.setSize(800, 600);
        frame.setVisible(true);

        // For demonstration purposes, load a recipe with ID 1
        recipePanel.loadRecipe(1);
    }

    private static class Recipe {
        private String name;
        private List<String> ingredients;

        public Recipe(String name, List<String> ingredients) {
            this.name = name;
            this.ingredients = ingredients;
        }

        public String getName() {
            return name;
        }

        public List<String> getIngredients() {
            return ingredients;
        }
    }
}
