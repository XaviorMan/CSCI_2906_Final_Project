package ai_Chef;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class RecipePanel extends JPanel {
    private static final long serialVersionUID = 1L;

    private JList<String> recipeList;
    private DefaultListModel<String> listModel;
    private JTextArea recipeDetails;
    private JTextField searchField;
    private JButton searchButton;

    public RecipePanel() {
        setLayout(new BorderLayout());

        // Recipe List
        listModel = new DefaultListModel<>();
        recipeList = new JList<>(listModel);
        recipeList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane listScrollPane = new JScrollPane(recipeList);

        // Recipe Details
        recipeDetails = new JTextArea();
        recipeDetails.setEditable(false);
        JScrollPane detailsScrollPane = new JScrollPane(recipeDetails);

        // Right Side Panel
        JPanel rightPanel = new JPanel(new BorderLayout());
        JPanel buttonPanel = new JPanel(new GridLayout(6, 1));

        JButton onHandButton = new JButton("On-hand Recipes");
        JButton allRecipesButton = new JButton("All Recipes");
        JButton savedRecipesButton = new JButton("Saved Recipes");
        JButton missing1Button = new JButton("Missing 1 Ingredient");
        JButton missing2Or3Button = new JButton("Missing 2 or 3 Ingredients");

        buttonPanel.add(onHandButton);
        buttonPanel.add(allRecipesButton);
        buttonPanel.add(savedRecipesButton);
        buttonPanel.add(missing1Button);
        buttonPanel.add(missing2Or3Button);

        searchField = new JTextField(20);
        searchButton = new JButton("Search");

        JPanel searchPanel = new JPanel();
        searchPanel.add(searchField);
        searchPanel.add(searchButton);

        rightPanel.add(buttonPanel, BorderLayout.CENTER);
        rightPanel.add(searchPanel, BorderLayout.SOUTH);

        // Middle Panel
        JPanel middlePanel = new JPanel(new BorderLayout());
        middlePanel.add(listScrollPane, BorderLayout.CENTER); // Add listScrollPane to the middle panel

        JButton singleListButton = new JButton("Single List");
        JButton doubleListButton = new JButton("Double List");

        JPanel layoutPanel = new JPanel(new GridLayout(1, 2));
        layoutPanel.add(singleListButton);
        layoutPanel.add(doubleListButton);

        middlePanel.add(detailsScrollPane, BorderLayout.SOUTH); // Add detailsScrollPane to the middle panel

        // Left Side Panel
        JPanel leftPanel = new JPanel(new BorderLayout());
        JPanel topFavoritesPanel = new JPanel(new BorderLayout());

        JLabel favoritesLabel = new JLabel("Favorite Recipes");
        topFavoritesPanel.add(favoritesLabel, BorderLayout.NORTH);

        JList<String> favoriteList = new JList<>(new DefaultListModel<>());
        JScrollPane favoriteScrollPane = new JScrollPane(favoriteList);
        topFavoritesPanel.add(favoriteScrollPane, BorderLayout.CENTER);

        leftPanel.add(topFavoritesPanel, BorderLayout.NORTH);
        leftPanel.add(new JLabel("Top 10 Recipes (Day, Week, Calendar)"), BorderLayout.CENTER);

        // Add Components
        add(leftPanel, BorderLayout.WEST);
        add(middlePanel, BorderLayout.CENTER); // Correctly add the middle panel to the center
        add(rightPanel, BorderLayout.EAST);

        // Event Listeners
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String query = searchField.getText();
                searchRecipes(query);
            }
        });

        recipeList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                String selectedRecipe = recipeList.getSelectedValue();
                displayRecipeDetails(selectedRecipe);
            }
        });

        // Add more listeners and functionalities for the new buttons as needed
        // Example:
        savedRecipesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Add functionality to handle displaying saved recipes
            }
        });
    }

    private void searchRecipes(String query) {
        // Call backend service to get search results
        RecipeService recipeService = new RecipeService();
        List<String> results = recipeService.searchRecipes(query);
        listModel.clear();
        for (String recipe : results) {
            listModel.addElement(recipe);
        }
    }

    private void displayRecipeDetails(String recipeName) {
        // Call backend service to get recipe details
        RecipeService recipeService = new RecipeService();
        Recipe recipe = recipeService.getRecipeDetails(recipeName);

        if (recipe != null) {
            StringBuilder details = new StringBuilder();
            details.append("Name: ").append(recipe.getName()).append("\n\n");
            details.append("Ingredients:\n");
            for (String ingredient : recipe.getIngredients()) {
                details.append("- ").append(ingredient).append("\n");
            }
            details.append("\nHealth Information:\n").append(recipe.getHealthInformation());

            recipeDetails.setText(details.toString());
        } else {
            recipeDetails.setText("Recipe not found.");
        }
    }
}
