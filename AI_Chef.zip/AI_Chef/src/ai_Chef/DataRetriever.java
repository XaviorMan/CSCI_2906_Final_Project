package ai_Chef;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DataRetriever {
    public static List<Recipe> getAllRecipes() {
        List<Recipe> recipes = new ArrayList<>();
        String sql = "SELECT * FROM recipes";

        try (Connection conn = DatabaseManager.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Recipe recipe = new Recipe(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("ingredients"),
                        rs.getString("instructions")
                );
                recipes.add(recipe);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return recipes;
    }

    public static List<Nutrient> getNutritionalInfo(int recipeId) {
        List<Nutrient> nutrients = new ArrayList<>();
        String sql = "SELECT * FROM nutritional_info WHERE recipe_id = ?";

        try (Connection conn = DatabaseManager.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, recipeId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Nutrient nutrient = new Nutrient(
                            rs.getString("nutrient_name"),
                            rs.getDouble("amount"),
                            rs.getString("unit")
                    );
                    nutrients.add(nutrient);
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return nutrients;
    }
}
