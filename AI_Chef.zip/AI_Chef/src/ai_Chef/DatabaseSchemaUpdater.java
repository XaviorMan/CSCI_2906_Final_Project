package ai_Chef;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseSchemaUpdater {
    public static void main(String[] args) {
        DatabaseSchemaUpdater updater = new DatabaseSchemaUpdater();
        updater.updateSchema();
    }

    public void updateSchema() {
        String addQuantityColumn = "ALTER TABLE ingredients ADD COLUMN quantity REAL;";
        String addRecipeIdColumn = "ALTER TABLE nutritional_info ADD COLUMN recipe_id INTEGER;";

        try (Connection conn = DatabaseManager.connect();
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(addQuantityColumn);
            stmt.executeUpdate(addRecipeIdColumn);
            System.out.println("Database schema updated successfully.");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
