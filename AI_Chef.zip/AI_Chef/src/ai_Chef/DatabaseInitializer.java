package ai_Chef;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;

public class DatabaseInitializer {
    public static void createTables() {
        String createRecipesTable = "CREATE TABLE IF NOT EXISTS recipes ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "name TEXT NOT NULL,"
                + "ingredients TEXT,"
                + "instructions TEXT"
                + ");";

        String createNutritionalInfoTable = "CREATE TABLE IF NOT EXISTS nutritional_info ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "recipe_id INTEGER,"
                + "nutrient_name TEXT NOT NULL,"
                + "amount REAL,"
                + "unit TEXT,"
                + "FOREIGN KEY (recipe_id) REFERENCES recipes(id)"
                + ");";

        try (Connection conn = DatabaseManager.connect();
             Statement stmt = conn.createStatement()) {
            stmt.execute(createRecipesTable);
            stmt.execute(createNutritionalInfoTable);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
