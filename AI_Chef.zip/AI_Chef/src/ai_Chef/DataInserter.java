package ai_Chef;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class DataInserter {
    public static void insertRecipe(String name, String ingredients, String instructions) {
        String sql = "INSERT INTO recipes(name, ingredients, instructions) VALUES(?, ?, ?)";

        try (Connection conn = DatabaseManager.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, ingredients);
            pstmt.setString(3, instructions);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void insertNutritionalInfo(int recipeId, List<Nutrient> nutrients) {
        String sql = "INSERT INTO nutritional_info(recipe_id, nutrient_name, amount, unit) VALUES(?, ?, ?, ?)";

        try (Connection conn = DatabaseManager.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            for (Nutrient nutrient : nutrients) {
                pstmt.setInt(1, recipeId);
                pstmt.setString(2, nutrient.getName());
                pstmt.setDouble(3, nutrient.getAmount());
                pstmt.setString(4, nutrient.getUnit());
                pstmt.addBatch();
            }
            pstmt.executeBatch();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
