package ai_Chef;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class HealthDataLoader {

    public static Map<String, String> loadHealthData(String filePath) {
        Map<String, String> healthData = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                String ingredient = values[0].trim();
                String healthInfo = values[1].trim(); // Adjust index based on actual CSV structure
                healthData.put(ingredient, healthInfo);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return healthData;
    }
}
