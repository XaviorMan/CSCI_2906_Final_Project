package ai_Chef;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class AI_ChefApp {
    public static void main(String[] args) {
        // Initialize the database and load data
        DatabaseInitializer.createTables();
        DataLoader.loadCSVData("src/ai_Chef/resources/datasets/FoodData_Central_Foundation_Food_csv_2024-04-18.csv",
                "src/ai_Chef/resources/datasets/FoodData_Central_sr_legacy_food_csv_2018-04.csv");
        DataLoader.loadJSONData("src/ai_Chef/resources/datasets/recipe-ingredients-dataset-metadata.json");

        // Insert sample data
        DataInserter.insertRecipe("Pasta", "Pasta, Tomato Sauce", "Boil pasta. Add sauce.");
        List<Nutrient> nutrients = new ArrayList<>();
        nutrients.add(new Nutrient("Calories", 200, "kcal"));
        nutrients.add(new Nutrient("Protein", 7, "g"));
        DataInserter.insertNutritionalInfo(1, nutrients); // Assume 1 is the recipe ID

        // Retrieve and print data
        List<Recipe> recipes = DataRetriever.getAllRecipes();
        for (Recipe recipe : recipes) {
            System.out.println("Recipe: " + recipe.getName());
            System.out.println("Ingredients: " + recipe.getIngredients());
            System.out.println("Instructions: " + recipe.getInstructions());
            List<Nutrient> recipeNutrients = DataRetriever.getNutritionalInfo(recipe.getId());
            for (Nutrient nutrient : recipeNutrients) {
                System.out.println(nutrient.getName() + ": " + nutrient.getAmount() + " " + nutrient.getUnit());
            }
        }

        // Launch the GUI
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("AI Chef");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(1200, 800);
            frame.setLayout(new BorderLayout());

            // Create an instance of ClockAndTimer
            ClockAndTimer clockAndTimer = new ClockAndTimer();

            // Navigation panel
            NavigationPanel navigationPanel = new NavigationPanel(clockAndTimer);
            frame.add(navigationPanel, BorderLayout.NORTH);

            // Main content area
            JPanel mainPanel = new JPanel(new CardLayout());
            HomePanel homePanel = new HomePanel();
            FridgePanel fridgePanel = new FridgePanel();
            RecipePanel recipesPanel = new RecipePanel();
            SettingsPanel settingsPanel = new SettingsPanel(clockAndTimer);

            mainPanel.add(homePanel, "Home");
            mainPanel.add(fridgePanel, "Fridge");
            mainPanel.add(recipesPanel, "Recipes");
            mainPanel.add(settingsPanel, "Settings");

            frame.add(mainPanel, BorderLayout.CENTER);

            // Pass the CardLayout and mainPanel to the NavigationPanel
            navigationPanel.setMainPanel(mainPanel);

            frame.setVisible(true);
        });
    }
}
