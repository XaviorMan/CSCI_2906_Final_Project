import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class SettingsPanel extends JPanel {
    private static final long serialVersionUID = 1L;
    private ClockAndTimer clockAndTimer;
    private JRadioButton standardTimeButton;
    private JRadioButton militaryTimeButton;

    public SettingsPanel(ClockAndTimer clockAndTimer) {
        this.clockAndTimer = clockAndTimer;
        setLayout(new GridLayout(3, 1));

        // Set Time Panel
        JPanel setTimePanel = new JPanel();
        setTimePanel.setBorder(BorderFactory.createTitledBorder("Set Time"));
        JButton setTimeButton = new JButton("Set Time");
        setTimePanel.add(setTimeButton);
        add(setTimePanel);

        // Time Format Panel
        JPanel timeFormatPanel = new JPanel();
        timeFormatPanel.setBorder(BorderFactory.createTitledBorder("Time Format"));
        standardTimeButton = new JRadioButton("Standard Time");
        militaryTimeButton = new JRadioButton("Military Time");
        ButtonGroup timeFormatGroup = new ButtonGroup();
        timeFormatGroup.add(standardTimeButton);
        timeFormatGroup.add(militaryTimeButton);
        standardTimeButton.setSelected(true);
        timeFormatPanel.add(standardTimeButton);
        timeFormatPanel.add(militaryTimeButton);
        add(timeFormatPanel);

        // Close Button Panel
        JPanel closePanel = new JPanel();
        JButton closeButton = new JButton("Close");
        closePanel.add(closeButton);
        add(closePanel);

        // Action listeners
        setTimeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String timeString = JOptionPane.showInputDialog(SettingsPanel.this, "Enter time (HH:mm:ss):", LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
                try {
                    LocalTime newTime = LocalTime.parse(timeString, DateTimeFormatter.ofPattern("HH:mm:ss"));
                    // Here, the time setting logic can be implemented if needed
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(SettingsPanel.this, "Invalid time format. Please use HH:mm:ss.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        standardTimeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clockAndTimer.setMilitaryTime(false);
            }
        });

        militaryTimeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clockAndTimer.setMilitaryTime(true);
            }
        });

        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.getWindowAncestor(SettingsPanel.this).dispose();
            }
        });
    }
}
