import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.List;
import java.util.ArrayList;
import org.apache.commons.dbcp2.BasicDataSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class RecipeService {
    private RecipeSearch recipeSearch;

    public RecipeService(RecipeSearch recipeSearch) {
        this.recipeSearch = recipeSearch;
    }

    public List<String> findRecipes(String query) {
        return recipeSearch.searchRecipesByIngredient(query);
    }
}
