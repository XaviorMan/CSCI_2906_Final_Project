import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class HomePanel extends JPanel {
    private static final long serialVersionUID = 1L;

    private JLabel breakfastLabel;
    private JLabel lunchLabel;
    private JLabel dinnerLabel;
    private JPanel weekPanel;
    private JTabbedPane ingredientsShoppingPane;
    private JLabel monthLabel;
    private JPanel calendarGrid;
    private LocalDate currentDate;
    private List<JLabel> dayLabels;

    public HomePanel() {
        setLayout(new BorderLayout());

        currentDate = LocalDate.now();

        // Day Panel for Breakfast, Lunch, and Dinner
        JPanel dayPanel = new JPanel(new GridLayout(2, 3));
        dayPanel.setBorder(BorderFactory.createTitledBorder("Day"));
        addBorderedLabel(dayPanel, "Breakfast");
        addBorderedLabel(dayPanel, "Lunch");
        addBorderedLabel(dayPanel, "Dinner");
        breakfastLabel = addBorderedLabel(dayPanel, "Meal for Breakfast");
        lunchLabel = addBorderedLabel(dayPanel, "Meal for Lunch");
        dinnerLabel = addBorderedLabel(dayPanel, "Meal for Dinner");

        // Week Panel for days of the week and meal times
        weekPanel = new JPanel(new GridLayout(2, 7));
        weekPanel.setBorder(BorderFactory.createTitledBorder("Week"));
        String[] days = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
        for (String day : days) {
            addBorderedLabel(weekPanel, day);
        }
        for (int i = 0; i < 7; i++) {
            JPanel dayMeals = new JPanel(new GridLayout(3, 1));
            addBorderedLabel(dayMeals, "Breakfast: Meal");
            addBorderedLabel(dayMeals, "Lunch: Meal");
            addBorderedLabel(dayMeals, "Dinner: Meal");
            dayMeals.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            weekPanel.add(dayMeals);
        }

        // Calendar Panel with month navigation
        JPanel calendarPanel = new JPanel(new BorderLayout());
        calendarPanel.setBorder(BorderFactory.createTitledBorder("Calendar"));
        JPanel monthNavigation = new JPanel(new FlowLayout());
        JButton previousMonth = new JButton("<");
        JButton nextMonth = new JButton(">");
        monthLabel = new JLabel();
        monthNavigation.add(previousMonth);
        monthNavigation.add(monthLabel);
        monthNavigation.add(nextMonth);
        calendarPanel.add(monthNavigation, BorderLayout.NORTH);

        calendarGrid = new JPanel(new GridLayout(6, 7));
        dayLabels = new ArrayList<>();
        for (int i = 0; i < 42; i++) {
            JLabel dayLabel = new JLabel("", SwingConstants.CENTER);
            dayLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            calendarGrid.add(dayLabel);
            dayLabels.add(dayLabel);
        }
        calendarPanel.add(calendarGrid, BorderLayout.CENTER);

        // Ingredients/Shopping List Panel with TabbedPane
        ingredientsShoppingPane = new JTabbedPane();
        ingredientsShoppingPane.add("Ingredients", new JLabel("Ingredients List"));
        ingredientsShoppingPane.add("Shopping List", new JLabel("Shopping List"));

        // Adding panels to the main layout
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.add(dayPanel);
        leftPanel.add(weekPanel);
        leftPanel.add(calendarPanel);

        add(leftPanel, BorderLayout.CENTER);

        // Adjusting the space for Ingredients/Shopping List panel
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.add(ingredientsShoppingPane, BorderLayout.CENTER);
        rightPanel.setPreferredSize(new Dimension(300, getHeight())); // Adjust width as needed
        add(rightPanel, BorderLayout.EAST);

        // Update the calendar for the current month
        updateCalendar();

        // Add action listeners for month navigation
        previousMonth.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentDate = currentDate.minusMonths(1);
                updateCalendar();
            }
        });

        nextMonth.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentDate = currentDate.plusMonths(1);
                updateCalendar();
            }
        });
    }

    // Helper method to add a JLabel with a border to a panel
    private JLabel addBorderedLabel(JPanel panel, String text) {
        JLabel label = new JLabel(text, SwingConstants.CENTER);
        label.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        panel.add(label);
        return label;
    }

    // Method to update the calendar display based on the current date
    private void updateCalendar() {
        YearMonth yearMonth = YearMonth.from(currentDate);
        LocalDate firstOfMonth = currentDate.withDayOfMonth(1);
        int dayOfWeek = firstOfMonth.getDayOfWeek().getValue() % 7; // Convert to Sunday=0, Monday=1, ..., Saturday=6
        int daysInMonth = yearMonth.lengthOfMonth();

        // Update month label
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM yyyy");
        monthLabel.setText(currentDate.format(formatter));

        // Clear previous labels
        for (JLabel dayLabel : dayLabels) {
            dayLabel.setText("");
        }

        // Fill in the days of the month
        for (int day = 1; day <= daysInMonth; day++) {
            int labelIndex = dayOfWeek + day - 1;
            dayLabels.get(labelIndex).setText(String.valueOf(day));
        }
    }

    // Methods to update the content dynamically
    public void updateBreakfast(String breakfast) {
        breakfastLabel.setText("Breakfast: " + breakfast);
    }

    public void updateLunch(String lunch) {
        lunchLabel.setText("Lunch: " + lunch);
    }

    public void updateDinner(String dinner) {
        dinnerLabel.setText("Dinner: " + dinner);
    }

    public void updateWeek(String[] weekDays) {
        for (int i = 0; i < weekDays.length; i++) {
            ((JLabel) weekPanel.getComponent(i)).setText(weekDays[i]);
        }
    }

    public void updateCalendar(String calendar) {
        // Implement calendar update logic here if needed
    }
}
